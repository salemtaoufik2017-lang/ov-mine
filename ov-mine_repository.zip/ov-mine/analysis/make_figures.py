"""Figures 4 to 9 and 11 of the paper. Run from the repository root after analysis/reanalyse.py and analysis/size_bands.py."""
import json, csv, sys, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ovmine.data import load
OUT = ROOT / "figures"
J = json.load(open(ROOT / "results/analysis/reanalysis_r2.json")); R = J["R"]
AN = json.load(open(ROOT / "results/analysis/analysis_v1.json"))
BANDS = json.load(open(ROOT / "results/analysis/bands_r2.json"))
RES = ROOT / "results/zero_shot"; R2 = ROOT / "results/supervised"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.grid": True, "grid.color": "#e6e6e6", "grid.linewidth": 0.8})
M = ["YOLOE-11s", "YOLOE-11m", "YOLOE-11l", "YOLO-World-s", "G-DINO-T", "G-DINO-B", "OWLv2-B"]
FILE = dict(zip(M, ["yoloe-11s-seg", "yoloe-11m-seg", "yoloe-11l-seg", "yolov8s-worldv2", "grounding-dino-tiny", "grounding-dino-base", "owlv2-base-patch16-ensemble"]))
RED, ORG, BLU, GRN, PUR, GOLD = "#b2182b", "#f4a460", "#2166ac", "#7fbf7b", "#7b3294", "#e08214"
SUP50, SUP95 = R["SUP|-|native"]["AP50"], R["SUP|-|native"]["AP50_95"]
def save(fig, name, w, h):
    fig.set_size_inches(w / 200, h / 200); fig.tight_layout(); fig.savefig(OUT / name, dpi=200); plt.close(fig)

# Fig 4: validation curves of the supervised reference
rows = [{k.strip(): float(v) for k, v in r.items()} for r in csv.DictReader(open(R2 / "logs/le_n111_d0_results.csv"))]
ep = [r["epoch"] for r in rows]; g = lambda k: [100 * r[k] for r in rows]
fig, ax = plt.subplots()
ax.plot(ep, g("metrics/mAP50(B)"), color=RED, lw=1.6, label="AP50")
ax.plot(ep, g("metrics/mAP50-95(B)"), color=ORG, lw=1.6, label="AP50-95")
ax.plot(ep, g("metrics/precision(B)"), color=BLU, lw=1.2, ls=":", label="precision")
ax.plot(ep, g("metrics/recall(B)"), color=GRN, lw=1.2, ls=":", label="recall")
be = J["CKPT"]["best_epoch"]; ax.axvline(be, color="#555", ls="--", lw=0.9)
ax.text(be + 1, 93, f"selected (epoch {be})", ha="left", fontsize=7, color="#555")
ax.set_xlabel("epoch"); ax.set_ylabel("% on the validation split"); ax.set_ylim(0, 100)
ax.legend(ncol=2, fontsize=7.5, frameon=False, loc="lower right")
save(fig, "fig4.png", 1016, 688)

# Fig 5: four prompt sets
sets = [("names", "names", BLU), ("domain1", "domain-1 (7 prompts)", "#c2571a"), ("domain", "domain (9 prompts)", "#f4a582"), ("describe", "describe", GRN)]
fig, axs = plt.subplots(2, 1, sharex=True)
x = np.arange(len(M)); w = 0.2
for ax, met, sup, lim in ((axs[0], "AP50", SUP50, 75), (axs[1], "AP50_95", SUP95, 45)):
    for i, (k, lab, c) in enumerate(sets):
        ax.bar(x + (i - 1.5) * w, [R[f"{m}|{k}|native"][met] for m in M], w, color=c, label=lab, edgecolor="white", lw=0.5)
    ax.axhline(sup, color=RED, ls="--", lw=1.4)
    ax.text(-0.45, sup + 1.5, "supervised reference (YOLO11s, 111 images, validation-selected)", color=RED, fontsize=7.5)
    ax.set_ylim(0, lim); ax.set_ylabel(("AP50" if met == "AP50" else "AP50-95") + " (%)")
axs[0].legend(ncol=4, fontsize=7.5, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 0.78), title="prompt set", title_fontsize=8)
axs[1].set_xticks(x); axs[1].set_xticklabels(M, rotation=25, ha="right")
save(fig, "fig5.png", 1556, 1282)

# Fig 6: accuracy against time
T = {"YOLOE-11s": 0.109, "YOLOE-11m": 0.070, "YOLOE-11l": 0.077, "YOLO-World-s": 0.064, "G-DINO-T": 0.599, "G-DINO-B": 0.783, "OWLv2-B": 0.859}
sty = {"YOLOE-11s": (BLU, "o"), "YOLOE-11m": (BLU, "o"), "YOLOE-11l": (BLU, "o"), "YOLO-World-s": ("#56a0d3", "s"),
       "G-DINO-T": (GOLD, "^"), "G-DINO-B": (GOLD, "^"), "OWLv2-B": (PUR, "D")}
off = {"YOLOE-11s": (0.012, 4), "YOLOE-11m": (-0.008, 5.5), "YOLOE-11l": (0.012, -6.5), "YOLO-World-s": (-0.004, -7.5), "G-DINO-T": (-0.25, 1.5), "G-DINO-B": (0.05, -6), "OWLv2-B": (0.0, 4.5)}
fig, ax = plt.subplots()
for m in M:
    c, mk = sty[m]; y = R[f"{m}|names|native"]["AP50"]
    ax.scatter(T[m], y, color=c, marker=mk, s=45, zorder=3)
    ax.text(T[m] + off[m][0], y + off[m][1], m, color=c, fontsize=7.5, ha="center")
ax.scatter(0.189, R["COCO|-|native"]["AP50"], color="#777", marker="*", s=120, zorder=3); ax.text(0.205, 11.5, "YOLO11s COCO", color="#777", fontsize=7.5)
ax.scatter(0.082, SUP50, color=RED, marker="*", s=140, zorder=3); ax.text(0.082, SUP50 + 4, "YOLO11s fine-tuned", color=RED, fontsize=7.5, ha="center")
ax.set_xscale("log"); ax.set_xlim(0.04, 2.3); ax.set_ylim(0, 72); ax.set_xlabel("seconds per image (GPU)"); ax.set_ylabel("AP50 (%)")
save(fig, "fig6.png", 1016, 801)

# Fig 7: size bands
lab = M + ["YOLO11s\n(COCO)", "YOLO11s\n(fine-tuned)"]
keys = [f"{FILE[m]}_names_test" for m in M] + ["coco_yolo11s_test"]
vals = [[AN[k]["small (<32^2)"], AN[k]["medium (32^2-96^2)"], AN[k]["large (>96^2)"]] for k in keys] + [[BANDS["SUP"]["small"], BANDS["SUP"]["medium"], BANDS["SUP"]["large"]]]
fig, ax = plt.subplots(); x = np.arange(len(lab)); w = 0.27
for i, (c, l) in enumerate(zip(["#c6dbef", "#6baed6", "#1f4e79"], ["small ($<32^2$ px)", "medium", "large ($>96^2$ px)"])):
    ax.bar(x + (i - 1) * w, [v[i] for v in vals], w, color=c, label=l, edgecolor="white", lw=0.5)
ax.axvline(6.5, color="#999", ls=":", lw=1); ax.set_xticks(x); ax.set_xticklabels(lab, rotation=25, ha="right")
ax.set_ylabel("AP50 (%)"); ax.set_ylim(0, 80); ax.legend(ncol=3, frameon=False, fontsize=8, loc="upper left")
save(fig, "fig7.png", 1556, 710)

# Fig 8: per class
cls = ["truck", "excavator", "wheel loader", "bulldozer", "dumper", "person", "car"]; cnt = [127, 65, 4, 5, 12, 16, 28]
ser = [("OWLv2-B, names", R["OWLv2-B|names|native"]["per_class"], PUR), ("G-DINO-T, names", R["G-DINO-T|names|native"]["per_class"], GOLD),
       ("YOLOE-11m, names", R["YOLOE-11m|names|native"]["per_class"], BLU), ("YOLO11s fine-tuned", R["SUP|-|native"]["per_class"], RED)]
fig, ax = plt.subplots(); x = np.arange(len(cls)); w = 0.2
for i, (l, pc, c) in enumerate(ser):
    ax.bar(x + (i - 1.5) * w, [pc.get(k, 0) for k in cls], w, color=c, label=l, edgecolor="white", lw=0.5)
ax.set_xticks(x); ax.set_xticklabels([f"{k}\n({n})" for k, n in zip(cls, cnt)]); ax.set_ylabel("AP50 (%)"); ax.set_ylim(0, 105)
ax.legend(ncol=2, frameon=False, fontsize=8, loc="upper right")
save(fig, "fig8.png", 1556, 709)

# Fig 9: pooled PR curves (IoU 0.5) and OWLv2 confidence histogram
_, gt = load(ROOT / "data", "test")
def pr_curve(pred):
    g = {}
    for r in gt: g.setdefault((r["image"], r["cls"]), []).append(r["box"])
    used = {k: np.zeros(len(v), bool) for k, v in g.items()}
    ps = sorted(pred, key=lambda r: -r["score"]); tp = []
    for r in ps:
        bx = np.array(g.get((r["image"], r["cls"]), []), float).reshape(-1, 4); ok = False
        if len(bx):
            b = np.array(r["box"]); x1 = np.maximum(bx[:, 0], b[0]); y1 = np.maximum(bx[:, 1], b[1]); x2 = np.minimum(bx[:, 2], b[2]); y2 = np.minimum(bx[:, 3], b[3])
            inter = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
            iou = inter / ((bx[:, 2] - bx[:, 0]) * (bx[:, 3] - bx[:, 1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter)
            j = int(np.argmax(iou))
            if iou[j] >= 0.5 and not used[(r["image"], r["cls"])][j]: used[(r["image"], r["cls"])][j] = True; ok = True
        tp.append(ok)
    tp = np.array(tp); c = np.cumsum(tp)
    return c / len(gt), c / np.arange(1, len(tp) + 1), np.array([r["score"] for r in ps]), tp
fig, (a1, a2) = plt.subplots(1, 2)
for l, f, c in (("OWLv2-B, names", RES / "owlv2-base-patch16-ensemble_names_test.json", PUR), ("G-DINO-T, names", RES / "grounding-dino-tiny_names_test.json", GOLD),
                ("YOLOE-11m, names", RES / "yoloe-11m-seg_names_test.json", BLU), ("YOLO11s fine-tuned", R2 / "le_n111_d0.json", RED)):
    rc, pr, _, _ = pr_curve(json.load(open(f))["predictions"]); a1.plot(rc, pr, color=c, lw=1.5, label=l)
a1.set_xlim(0, 1); a1.set_ylim(0, 1); a1.set_xlabel("recall"); a1.set_ylabel("precision"); a1.legend(frameon=False, fontsize=7.5, loc="upper right")
_, _, sc, tp = pr_curve(json.load(open(RES / "owlv2-base-patch16-ensemble_names_test.json"))["predictions"])
bins = np.linspace(0, 1, 26)
a2.hist(sc[tp], bins=bins, color="#2f6db5", alpha=0.95, label="matched a box"); a2.hist(sc[~tp], bins=bins, color="#e07b6f", alpha=0.6, label="did not")
a2.set_yscale("log"); a2.axvline(0.25, color="#444", ls="--", lw=1.2); a2.text(0.27, 80, "operating point", fontsize=7.5, color="#444")
a2.set_xlabel("confidence (OWLv2-B, names)"); a2.set_ylabel("detections"); a2.legend(frameon=False, fontsize=7.5)
save(fig, "fig9.png", 1546, 688)

# Fig 11: label efficiency, five draws
by = {}
for k, v in J["LE"].items(): by.setdefault(v["images"], []).append((v["AP50"], v["AP50_95"]))
ns = sorted(by); a50 = [np.array([t[0] for t in by[n]]) for n in ns]; a95 = [np.array([t[1] for t in by[n]]) for n in ns]
zs = R["OWLv2-B|names|native"]["AP50"]
fig, ax = plt.subplots()
m50 = [a.mean() for a in a50]; m95 = [a.mean() for a in a95]
ax.errorbar(ns, m50, yerr=[[m - a.min() for m, a in zip(m50, a50)], [a.max() - m for m, a in zip(m50, a50)]], color=RED, marker="o", ms=5, lw=1.6, capsize=3, label="AP50")
ax.errorbar(ns, m95, yerr=[[m - a.min() for m, a in zip(m95, a95)], [a.max() - m for m, a in zip(m95, a95)]], color=ORG, marker="s", ms=4.5, lw=1.4, capsize=3, label="AP50-95")
ax.axhline(zs, color=PUR, ls="--", lw=1.2); ax.text(60, zs + 1.5, "best zero-shot (OWLv2-B, names)", color=PUR, fontsize=7.5)
xc = ns[0] + (zs - m50[0]) / (m50[1] - m50[0]) * (ns[1] - ns[0])
ax.scatter([xc], [zs], marker="v", color=PUR, s=60, zorder=4); ax.text(xc + 4, zs - 7, f"about {xc:.0f} images", color=PUR, fontsize=7.5)
ax.set_xlabel("labelled training images"); ax.set_ylabel("test AP (%)"); ax.set_ylim(0, 65); ax.legend(frameon=False, loc="lower right", fontsize=8)
save(fig, "fig11.png", 1016, 748)
print("crossing", xc)
