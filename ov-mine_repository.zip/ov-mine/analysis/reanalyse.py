"""Paper analysis (bootstrap intervals, class-wise NMS, paired tests, 3-class comparison, pycocotools, label efficiency).
Run from the repository root:  python analysis/reanalyse.py   (needs the images in ./data)
Second-revision analysis: original runs plus the round-2 runs (Domain-1 prompts, validation-selected supervised model): bootstrap intervals, class-wise NMS, 3-class
comparison, pycocotools cross-check, near-duplicate check. Uses the paper's evaluator rules (ovmine/mapeval.py)."""
import json, csv, sys, glob, io, contextlib
from pathlib import Path
import numpy as np
from PIL import Image
import imagehash

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
RES = ROOT / "results" / "zero_shot"
SUPD = ROOT / "results" / "supervised"
NAMES = ["truck", "excavator", "wheel loader", "bulldozer", "dumper", "person", "car"]
THRS = np.round(np.arange(0.5, 0.96, 0.05), 2)
B = 2000
rng_seed = 0

# ---------------- ground truth (ovmine/data.py rules)
test_ids = {Path(r["nombre"]).stem for r in csv.DictReader(open(DATA / "val_split.csv"))}
imgs = sorted(DATA.glob("*.jpg"))
test = [p for p in imgs if p.stem in test_ids]; train = [p for p in imgs if p.stem not in test_ids]
GT = {}
for p in test:
    w, h = Image.open(p).size
    rows = []
    lab = p.with_suffix(".txt")
    if lab.exists():
        for line in lab.read_text().splitlines():
            v = line.split()
            if len(v) < 5: continue
            c, x, y, bw, bh = int(float(v[0])), *map(float, v[1:5])
            rows.append((c, (x - bw / 2) * w, (y - bh / 2) * h, (x + bw / 2) * w, (y + bh / 2) * h))
    GT[p.name] = rows
print("test images", len(GT), "boxes", sum(map(len, GT.values())), "train images", len(train))

def iou(a, b):
    a = np.asarray(a, float).reshape(-1, 4); b = np.asarray(b, float).reshape(-1, 4)
    if not len(a) or not len(b): return np.zeros((len(a), len(b)))
    x1 = np.maximum(a[:, None, 0], b[None, :, 0]); y1 = np.maximum(a[:, None, 1], b[None, :, 1])
    x2 = np.minimum(a[:, None, 2], b[None, :, 2]); y2 = np.minimum(a[:, None, 3], b[None, :, 3])
    inter = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
    area_a = ((a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1]))[:, None]
    return inter / (area_a + ((b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1]))[None, :] - inter + 1e-9)

def per_image_tp(preds):
    """{img: {cls: {thr: (scores, tp)}}} with the paper's rule: best-IoU GT, FP if that GT is already taken."""
    by = {}
    for r in preds: by.setdefault(r["image"], []).append(r)
    out = {}
    for im in GT:
        ps = sorted(by.get(im, []), key=lambda r: -r["score"])
        out[im] = {}
        for c in range(len(NAMES)):
            g = [b[1:] for b in GT[im] if b[0] == c]
            pc = [r for r in ps if r["cls"] == c]
            sc = np.array([r["score"] for r in pc])
            ious = iou([r["box"] for r in pc], g) if pc and g else np.zeros((len(pc), len(g)))
            d = {}
            for t in THRS:
                taken = np.zeros(len(g), bool); tp = np.zeros(len(pc), bool)
                for i in range(len(pc)):
                    if len(g):
                        j = int(np.argmax(ious[i]))
                        if ious[i, j] >= t and not taken[j]: taken[j] = True; tp[i] = True
                d[float(t)] = (sc, tp)
            out[im][c] = d
    return out

def ap_paper(scores, tp, n_gt):
    if n_gt == 0: return np.nan
    if len(scores) == 0: return 0.0
    o = np.argsort(-scores, kind="stable"); t = tp[o].astype(float)
    ctp = np.cumsum(t); cfp = np.cumsum(1 - t)
    rec = ctp / n_gt; prec = ctp / np.maximum(ctp + cfp, 1e-9)
    mrec = np.concatenate(([0.0], rec, [rec[-1]])); mpre = np.concatenate(([1.0], prec, [0.0]))
    mpre = np.maximum.accumulate(mpre[::-1])[::-1]
    i = np.where(mrec[1:] != mrec[:-1])[0]
    return float(np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1]))

def score(tab, ims, classes=range(len(NAMES)), thrs=(0.5,)):
    per = {}
    for c in classes:
        n = sum(sum(1 for b in GT[i] if b[0] == c) for i in ims)
        if n == 0: continue
        aps = []
        for t in thrs:
            sc = np.concatenate([tab[i][c][float(t)][0] for i in ims]); tp = np.concatenate([tab[i][c][float(t)][1] for i in ims])
            aps.append(ap_paper(sc, tp, n))
        per[c] = float(np.mean(aps))
    return 100 * float(np.mean(list(per.values()))), {NAMES[c]: 100 * v for c, v in per.items()}

def nms_classwise(preds, thr=0.5, cap=100):
    out = []
    by = {}
    for r in preds: by.setdefault((r["image"], r["cls"]), []).append(r)
    per_img = {}
    for (im, c), rs in by.items():
        rs = sorted(rs, key=lambda r: -r["score"]); keep = []
        boxes = np.array([r["box"] for r in rs])
        alive = np.ones(len(rs), bool)
        for i in range(len(rs)):
            if not alive[i]: continue
            keep.append(rs[i])
            if i + 1 < len(rs):
                alive[i + 1:] &= iou(boxes[i:i + 1], boxes[i + 1:])[0] < thr
        per_img.setdefault(im, []).extend(keep)
    for im, rs in per_img.items(): out += sorted(rs, key=lambda r: -r["score"])[:cap]
    return out

# ---------------- near-duplicate clusters (pHash <= 10)
H = {p.name: imagehash.phash(Image.open(p)) for p in imgs}
names = list(GT)
parent = {n: n for n in names}
def find(x):
    while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
    return x
for i, a in enumerate(names):
    for b in names[i + 1:]:
        if H[a] - H[b] <= 10: parent[find(a)] = find(b)
groups = {}
for n in names: groups.setdefault(find(n), []).append(n)
groups = list(groups.values())
dup_with_train = [n for n in names if any(H[n] - H[p.name] <= 10 for p in train)]
print("clusters among test images:", len(groups), "| test images with a near-duplicate in train:", len(dup_with_train))

rng = np.random.default_rng(rng_seed)
DRAWS_C = [rng.integers(0, len(groups), len(groups)) for _ in range(B)]
DRAWS_I = [rng.integers(0, len(names), len(names)) for _ in range(B)]
def ims_c(d): return [im for g in d for im in groups[g]]
def ims_i(d): return [names[k] for k in d]

# ---------------- load runs
MODELS = {"YOLOE-11s": "yoloe-11s-seg", "YOLOE-11m": "yoloe-11m-seg", "YOLOE-11l": "yoloe-11l-seg",
          "YOLO-World-s": "yolov8s-worldv2", "G-DINO-T": "grounding-dino-tiny", "G-DINO-B": "grounding-dino-base",
          "OWLv2-B": "owlv2-base-patch16-ensemble"}
runs = {}
for m, f in MODELS.items():
    for ps in ("names", "domain", "describe"):
        runs[(m, ps)] = json.load(open(RES / f"{f}_{ps}_test.json"))["predictions"]
runs[("COCO", "-")] = json.load(open(ROOT / "results/references/coco_yolo11s_test.json"))["predictions"]
runs[("SUPold", "-")] = json.load(open(ROOT / "results/first_version/finetuned_yolo11s_test.json"))["predictions"]
runs[("SUP", "-")] = json.load(open(SUPD / "le_n111_d0.json"))["predictions"]
for m, f in MODELS.items():
    runs[(m, "domain1")] = json.load(open(RES / f"{f}_domain1_test.json"))["predictions"]
COCO3 = [0, 6, 5]      # truck, car, person

R, BOOT, BOOTI, TABS = {}, {}, {}, {}
for key, pr in runs.items():
    for proto in ("native", "nms"):
        if proto == "nms" and key[0] in ("COCO", "SUP", "SUPold"): continue
        p2 = pr if proto == "native" else nms_classwise(pr)
        tab = per_image_tp(p2); TABS[key + (proto,)] = tab
        cls = COCO3 if key[0] == "COCO" else range(len(NAMES))
        a50, pc = score(tab, names, cls); a95, _ = score(tab, names, cls, THRS)
        bc = np.array([score(tab, ims_c(d), cls)[0] for d in DRAWS_C])
        bi = np.array([score(tab, ims_i(d), cls)[0] for d in DRAWS_I])
        R[key + (proto,)] = {"AP50": a50, "AP50_95": a95, "per_class": pc, "n_pred": len(p2),
                             "CI_cluster": list(np.percentile(bc, [2.5, 97.5])), "CI_image": list(np.percentile(bi, [2.5, 97.5]))}
        BOOT[key + (proto,)] = bc; BOOTI[key + (proto,)] = bi
        print(key, proto, f"AP50 {a50:.1f} [{R[key + (proto,)]['CI_cluster'][0]:.1f}, {R[key + (proto,)]['CI_cluster'][1]:.1f}] AP50-95 {a95:.1f} n={len(p2)}")
        sys.stdout.flush()

def pdiff(k1, k2, boot=BOOT):
    d = boot[k1] - boot[k2]; lo, hi = np.percentile(d, [2.5, 97.5])
    return float(R[k1]["AP50"] - R[k2]["AP50"]), float(lo), float(hi)   # point estimate on the full test set, percentile interval

D = {}
for m in MODELS:
    for proto in ("native", "nms"):
        D[f"{m}|names-describe|{proto}"] = pdiff((m, "names", proto), (m, "describe", proto))
        D[f"{m}|names-domain|{proto}"] = pdiff((m, "names", proto), (m, "domain", proto))
for a_, b_ in (("YOLOE-11l", "YOLOE-11s"), ("YOLOE-11m", "YOLOE-11s"), ("G-DINO-B", "G-DINO-T"), ("OWLv2-B", "G-DINO-T"), ("OWLv2-B", "G-DINO-B")):
    D[f"{a_}-{b_}|names|native"] = pdiff((a_, "names", "native"), (b_, "names", "native"))
D["G-DINO-B|domain-names|native"] = pdiff(("G-DINO-B", "domain", "native"), ("G-DINO-B", "names", "native"))
D["SUP-OWLv2names"] = pdiff(("SUP", "-", "native"), ("OWLv2-B", "names", "native"))
D["SUPold-SUP"] = pdiff(("SUPold", "-", "native"), ("SUP", "-", "native"))
for m in MODELS:
    for proto in ("native", "nms"):
        D[f"{m}|names-domain1|{proto}"] = pdiff((m, "names", proto), (m, "domain1", proto))
        D[f"{m}|domain1-domain|{proto}"] = pdiff((m, "domain1", proto), (m, "domain", proto))
        D[f"{m}|domain1-describe|{proto}"] = pdiff((m, "domain1", proto), (m, "describe", proto))

# person-only intervals
PERSON = {}
for key in (("G-DINO-T", "describe"), ("G-DINO-T", "names"), ("G-DINO-B", "describe"), ("OWLv2-B", "names"), ("SUP", "-"), ("SUPold", "-")):
    tab = TABS[key + ("native",)]
    v = np.array([score(tab, ims_c(d), [5])[0] for d in DRAWS_C]); PERSON[f"{key[0]}|{key[1]}"] = [score(tab, names, [5])[0]] + list(np.percentile(v, [2.5, 97.5]))

# three-class / four-class means
THREE = {}
for key, r in R.items():
    if key[2] != "native": continue
    pc = r["per_class"]
    three = np.mean([pc[n] for n in ("truck", "car", "person") if n in pc])
    four = float(np.mean([pc[n] for n in ("excavator", "wheel loader", "bulldozer", "dumper") if n in pc])) if key[0] != "COCO" else None
    THREE[f"{key[0]}|{key[1]}"] = (three, four)

# pycocotools
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
def coco_eval(preds, classes):
    ids = {n: i + 1 for i, n in enumerate(names)}
    anns, k = [], 1
    for n in names:
        for c, x1, y1, x2, y2 in GT[n]:
            if c in classes: anns.append({"id": k, "image_id": ids[n], "category_id": c + 1, "bbox": [x1, y1, x2 - x1, y2 - y1], "area": (x2 - x1) * (y2 - y1), "iscrowd": 0}); k += 1
    cg = COCO()
    cg.dataset = {"images": [{"id": i} for i in ids.values()], "annotations": anns, "categories": [{"id": c + 1} for c in classes]}
    with contextlib.redirect_stdout(io.StringIO()):
        cg.createIndex()
        dt = [{"image_id": ids[r["image"]], "category_id": r["cls"] + 1, "bbox": [r["box"][0], r["box"][1], r["box"][2] - r["box"][0], r["box"][3] - r["box"][1]], "score": r["score"]} for r in preds if r["cls"] in classes and r["image"] in ids]
        cd = cg.loadRes(dt); E = COCOeval(cg, cd, "bbox"); E.params.maxDets = [1, 10, 100]
        E.params.catIds = sorted({a["category_id"] for a in anns}); E.evaluate(); E.accumulate(); E.summarize()
    return 100 * E.stats[1], 100 * E.stats[0]
PYC = {}
for key, pr in runs.items():
    cls = COCO3 if key[0] == "COCO" else list(range(len(NAMES)))
    PYC[f"{key[0]}|{key[1]}"] = coco_eval(pr, cls)
keys_sp = [k for k in runs if k[0] != "SUPold"]
ours = [R[k + ("native",)]["AP50"] for k in keys_sp]; theirs = [PYC[f"{k[0]}|{k[1]}"][0] for k in keys_sp]
rk = lambda x: np.argsort(np.argsort(x))
spearman = float(np.corrcoef(rk(ours), rk(theirs))[0, 1])

# checkpoint selection of the round-2 supervised reference (validation split only)
def ckpt(path):
    rows = [{k.strip(): v for k, v in r.items()} for r in csv.DictReader(open(path))]
    fit = [0.1 * float(r["metrics/mAP50(B)"]) + 0.9 * float(r["metrics/mAP50-95(B)"]) for r in rows]
    b = int(np.argmax(fit))
    return {"best_epoch": int(float(rows[b]["epoch"])), "val_AP50": 100 * float(rows[b]["metrics/mAP50(B)"]),
            "val_AP5095": 100 * float(rows[b]["metrics/mAP50-95(B)"]), "epochs": len(rows)}
CKPT = ckpt(SUPD / "logs" / "le_n111_d0_results.csv")

# size bands, operating point and recall ceiling for a prediction list (paper's rules)
def area(b): return (b[2] - b[0]) * (b[3] - b[1])
BANDS = {"small": (0, 32**2), "medium": (32**2, 96**2), "large": (96**2, 1e18)}
def extras(preds):
    out = {}
    for bn, (lo, hi) in BANDS.items():
        gsave = {k: v for k, v in GT.items()}
        for k in GT: GT[k] = [g for g in gsave[k] if lo <= area(g[1:]) < hi]
        p = [r for r in preds if lo <= area(r["box"]) < hi]
        out[bn] = score(per_image_tp(p), names)[0]
        GT.update(gsave)
    tp_all = per_image_tp([r for r in preds if r["score"] >= 0.25])
    tp = sum(int(tp_all[i][c][0.5][1].sum()) for i in names for c in range(len(NAMES)))
    kept = sum(1 for r in preds if r["score"] >= 0.25); ngt = sum(len(v) for v in GT.values())
    full = per_image_tp(preds)
    out.update({"P": 100 * tp / max(kept, 1), "R": 100 * tp / ngt, "kept": kept,
                "max_recall": 100 * sum(int(full[i][c][0.5][1].sum()) for i in names for c in range(len(NAMES))) / ngt})
    return out
EXTRA = {"SUP": extras(runs[("SUP", "-")]), "SUPold": extras(runs[("SUPold", "-")])}
for m in MODELS: EXTRA[m + "|domain1"] = extras(runs[(m, "domain1")])

# label efficiency: every draw rescored with this evaluator
LE = {}
for f in sorted(SUPD.glob("le_n*_d*.json")):
    j = json.load(open(f)); tab = per_image_tp(j["predictions"])
    LE[f.stem] = {"images": j["images"], "AP50": score(tab, names)[0], "AP50_95": score(tab, names, range(len(NAMES)), THRS)[0],
                  "ckpt": ckpt(SUPD / "logs" / (f.stem + "_results.csv")), "train_images": j["train_images"]}
out = {"groups": len(groups), "dup_with_train": len(dup_with_train), "R": {"|".join(k): v for k, v in R.items()},
       "D": D, "PERSON": PERSON, "THREE": THREE, "PYC": PYC, "spearman": spearman, "CKPT": CKPT, "EXTRA": EXTRA, "LE": LE}
json.dump(out, open(ROOT / "results/analysis/reanalysis_r2.json", "w"), indent=1, default=float)
print(json.dumps({"CKPT": CKPT, "spearman": spearman}, indent=1))
