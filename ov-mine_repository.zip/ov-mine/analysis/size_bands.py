"""AP50 by object size (COCO bands) with the paper's evaluator. Run from the repository root."""
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from ovmine.data import load
from ovmine.mapeval import evaluate
_, gt = load(ROOT / "data", "test")
BANDS = {"small": (0, 32**2), "medium": (32**2, 96**2), "large": (96**2, 1e18)}
files = {"SUPold": ROOT / "results/first_version/finetuned_yolo11s_test.json", "SUP": ROOT / "results/supervised/le_n111_d0.json"}
for m, f in [("YOLOE-11s", "yoloe-11s-seg"), ("YOLOE-11m", "yoloe-11m-seg"), ("YOLOE-11l", "yoloe-11l-seg"), ("YOLO-World-s", "yolov8s-worldv2"),
             ("G-DINO-T", "grounding-dino-tiny"), ("G-DINO-B", "grounding-dino-base"), ("OWLv2-B", "owlv2-base-patch16-ensemble")]:
    files[m + "|domain1"] = ROOT / f"results/zero_shot/{f}_domain1_test.json"
out = {k: {b: 100 * evaluate(gt, json.load(open(f))["predictions"], list(range(7)), a)["AP50"] for b, a in BANDS.items()} for k, f in files.items()}
json.dump(out, open(ROOT / "results/analysis/bands_r2.json", "w"), indent=1)
for k, v in out.items(): print(k, {b: round(x, 1) for b, x in v.items()})
