"""Open-vocabulary mining evaluation package."""
