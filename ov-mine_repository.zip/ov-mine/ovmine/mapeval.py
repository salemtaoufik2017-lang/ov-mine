"""Standalone COCO-style mAP for open-vocabulary predictions.

Ground truth and predictions are lists of dicts with keys
  image, cls (int), box (x1,y1,x2,y2 in pixels), and score for predictions.
AP is computed per class with all-point interpolation, then averaged over
IoU thresholds 0.50:0.05:0.95 (mAP50-95) and at 0.50 (mAP50).
"""
from __future__ import annotations

import numpy as np


def iou_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    if len(a) == 0 or len(b) == 0:
        return np.zeros((len(a), len(b)), np.float32)
    x1 = np.maximum(a[:, None, 0], b[None, :, 0]); y1 = np.maximum(a[:, None, 1], b[None, :, 1])
    x2 = np.minimum(a[:, None, 2], b[None, :, 2]); y2 = np.minimum(a[:, None, 3], b[None, :, 3])
    inter = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
    ar_a = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1])
    ar_b = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
    return inter / (ar_a[:, None] + ar_b[None, :] - inter + 1e-9)


def ap_at(gt, pred, cls, thr, area=None):
    """AP of one class at one IoU threshold. area = (min, max) box area filter in px^2."""
    def keep(box):
        if area is None:
            return True
        a = (box[2] - box[0]) * (box[3] - box[1])
        return area[0] <= a < area[1]

    g = {}
    n_gt = 0
    for r in gt:
        if r["cls"] == cls and keep(r["box"]):
            g.setdefault(r["image"], []).append(r["box"])
            n_gt += 1
    if n_gt == 0:
        return np.nan
    p = sorted([r for r in pred if r["cls"] == cls], key=lambda r: -r["score"])
    matched = {k: np.zeros(len(v), bool) for k, v in g.items()}
    tp, fp = [], []
    for r in p:
        boxes = np.array(g.get(r["image"], []), np.float32).reshape(-1, 4)
        ious = iou_matrix(np.array([r["box"]], np.float32), boxes)[0] if len(boxes) else np.zeros(0)
        j = int(np.argmax(ious)) if len(ious) else -1
        if j >= 0 and ious[j] >= thr and not matched[r["image"]][j]:
            matched[r["image"]][j] = True
            tp.append(1); fp.append(0)
        else:
            if not keep(r["box"]):     # prediction outside the size band: ignore it
                continue
            tp.append(0); fp.append(1)
    if not tp:
        return 0.0
    tp = np.cumsum(tp); fp = np.cumsum(fp)
    rec = tp / n_gt
    prec = tp / np.maximum(tp + fp, 1e-9)
    mrec = np.concatenate(([0.0], rec, [rec[-1]]))
    mpre = np.concatenate(([1.0], prec, [0.0]))
    mpre = np.maximum.accumulate(mpre[::-1])[::-1]          # all-point interpolation
    i = np.where(mrec[1:] != mrec[:-1])[0]
    return float(np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1]))


def evaluate(gt, pred, classes, area=None):
    """Return dict with AP50, AP50_95 overall and per class."""
    thrs = np.arange(0.5, 0.96, 0.05)
    per = {}
    for c in classes:
        aps = [ap_at(gt, pred, c, t, area) for t in thrs]
        per[c] = {"AP50": aps[0], "AP50_95": float(np.nanmean(aps)) if not np.all(np.isnan(aps)) else np.nan}
    ok = [c for c in classes if not np.isnan(per[c]["AP50"])]
    return {"AP50": float(np.mean([per[c]["AP50"] for c in ok])) if ok else np.nan,
            "AP50_95": float(np.mean([per[c]["AP50_95"] for c in ok])) if ok else np.nan,
            "per_class": per, "n_classes_scored": len(ok)}
