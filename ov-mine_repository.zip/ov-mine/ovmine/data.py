"""Load the open-pit machinery dataset (YOLO txt labels) and its official validation split."""
from __future__ import annotations

import csv
from pathlib import Path

import cv2

NAMES = ["truck", "excavator", "wheel loader", "bulldozer", "dumper", "person", "car"]


def load(root: Path, split: str = "all"):
    """Return (image paths, ground-truth records). split: all | test | train.
    The test split is the 40 files listed in val_split.csv, as released with the data."""
    root = Path(root)
    test_ids = set()
    csv_path = root / "val_split.csv"
    if csv_path.exists():
        test_ids = {Path(r["nombre"]).stem for r in csv.DictReader(open(csv_path))}
    imgs = sorted(root.glob("*.jpg"))
    if split == "test":
        imgs = [p for p in imgs if p.stem in test_ids]
    elif split == "train":
        imgs = [p for p in imgs if p.stem not in test_ids]
    gt = []
    for p in imgs:
        h, w = cv2.imread(str(p)).shape[:2]
        lab = p.with_suffix(".txt")
        if not lab.exists():
            continue
        for line in lab.read_text().splitlines():
            v = line.split()
            if len(v) < 5:
                continue
            c, x, y, bw, bh = int(float(v[0])), *map(float, v[1:5])
            gt.append({"image": p.name, "cls": c,
                       "box": [(x - bw / 2) * w, (y - bh / 2) * h, (x + bw / 2) * w, (y + bh / 2) * h]})
    return imgs, gt
