"""Prompt sets for open-vocabulary detection. Each entry maps a prompt to a dataset class id."""
from .data import NAMES

PROMPTS = {
    # P1: the dataset's own class names
    "names": {n: i for i, n in enumerate(NAMES)},
    # P2: the words a mining engineer would use
    "domain": {"haul truck": 0, "dump truck": 0, "hydraulic excavator": 1, "wheel loader": 2,
               "front end loader": 2, "bulldozer": 3, "articulated dumper": 4, "mine worker": 5,
               "pickup truck": 6},
    # P2 with one term per class (the first Domain term of each class), added in the second revision
    "domain1": {"haul truck": 0, "hydraulic excavator": 1, "wheel loader": 2, "bulldozer": 3,
                "articulated dumper": 4, "mine worker": 5, "pickup truck": 6},
    # P3: descriptive phrases
    "describe": {"large yellow mining haul truck carrying rock": 0,
                 "tracked excavator with a boom and bucket": 1,
                 "wheel loader with a large front bucket": 2,
                 "bulldozer with a straight blade on tracks": 3,
                 "articulated dump truck on a haul road": 4,
                 "person wearing a high visibility vest": 5,
                 "small car or pickup on a mine site": 6},
}
