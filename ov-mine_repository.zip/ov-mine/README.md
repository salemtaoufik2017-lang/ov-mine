# OV-Mine: open-vocabulary detection of open-pit mining equipment

Code, prompts, predictions and training logs for the paper

> R. Ghodhbani and T. Saidani, "Open-Vocabulary Object Detection for Open-Pit Mining Equipment: A Case Study of Prompt Formulation, Model Scale and Object Size Effects on Zero-Shot Accuracy", *International Journal of Intelligent Engineering and Systems* (paper ID 20266235, under review).

Every table and figure of the paper can be recomputed from the files in `results/` without running any detector. The images are only needed to rescore predictions against the ground-truth boxes.

## Data

The 171 images and YOLO labels come from the Kaggle dataset "Mining Process Basic Deep Learning" by C. Cartagena Matos (version 5, 2021): https://www.kaggle.com/datasets/cristianminas/mining-process-basic-deep-learning

The Kaggle page states no licence, so this repository does not include the images. Download the dataset and put its files (the `.jpg`/`.txt` pairs and `val_split.csv`) in a folder called `data/` at the repository root. The released `val_split.csv` defines the 40 test images.

## Splits

`splits/split.json` holds the division used in the paper, also available as `splits/{train,val,test}_images.txt`:

- 111 training images and 20 validation images, drawn from the 131 non-test images with seed 0;
- the 40 test images released with the dataset.

Near-duplicate frames (perceptual-hash distance of 10 or less) stay on one side of the split, and each class appears in both the training and the validation part. `scripts/make_split.py` recreates the file.

## Prompt sets

`ovmine/prompts.py` defines the four prompt sets and their mapping to the seven classes (truck, excavator, wheel loader, bulldozer, dumper, person, car):

| Set | Prompts | Description |
|---|---|---|
| `names` | 7 | the dataset's class names |
| `domain` | 9 | mining vocabulary, with two synonyms each for truck and wheel loader |
| `domain1` | 7 | the first mining term of each class |
| `describe` | 7 | descriptive phrases |

## Contents

| Path | What it holds |
|---|---|
| `ovmine/mapeval.py` | the evaluator: greedy matching, all-point interpolated AP, macro average over classes, optional size bands |
| `scripts/run_zeroshot.py` | YOLOE and YOLO-World runs (Ultralytics 8.4.155, 640 px, confidence floor 0.001, at most 100 detections) |
| `scripts/run_hf_zeroshot.py` | Grounding DINO and OWLv2 runs (Hugging Face, score floor 0.05) |
| `scripts/train_sup.py` | supervised reference and label-efficiency runs; checkpoint chosen on the validation split, test split scored once |
| `notebooks/IJIES_round2_experiments.ipynb` | Colab notebook that ran the Domain-1 prompts, the Names reproduction check and all 20 supervised runs |
| `analysis/reanalyse.py` | bootstrap intervals (2,000 image resamples, seed 0), class-wise NMS protocol, paired differences, three-class comparison, pycocotools cross-check, label-efficiency summary |
| `analysis/size_bands.py`, `analysis/make_figures.py` | size-band AP and Figs. 4 to 9 and 11 |
| `results/zero_shot/` | predictions of all 28 zero-shot configurations (7 detectors × 4 prompt sets) |
| `results/references/` | the COCO-pretrained YOLO11s reference |
| `results/supervised/` | predictions of the 20 supervised runs, `le_n{size}_d{draw}.json`. Each file lists its training images and seed. `le_n111_d0` is the supervised reference. |
| `results/supervised/logs/` | Ultralytics training logs (`*_results.csv`) and arguments (`*_args.yaml`) of every run |
| `results/supervised/weights/` | weights of the supervised reference |
| `results/first_version/` | the first-submission supervised model, whose checkpoint was selected on the test split. It is kept only to document the comparison made in Section 4.1. |
| `results/analysis/` | the analysis outputs quoted in the paper |
| `results/environment.json` | library versions and GPU of the second-revision runs |

Every prediction file has one entry per detection: `image`, `cls` (the class index after the prompt-to-class mapping), `box` (x1, y1, x2, y2 in pixels) and `score`.

## Reproducing the paper

```bash
pip install -r requirements.txt
# rescore everything from the saved predictions (needs data/)
python analysis/reanalyse.py      # about 5 minutes on a laptop CPU
python analysis/size_bands.py
python analysis/make_figures.py
# rerun a detector, e.g. OWLv2 with the one-term-per-class mining prompts
python scripts/run_hf_zeroshot.py --data data --model google/owlv2-base-patch16-ensemble --prompts domain1
# retrain the supervised reference or one label-efficiency draw (GPU)
python scripts/train_sup.py le 111 0
python scripts/train_sup.py le 28 3
```

The easiest way to rerun all the second-revision experiments on a free T4 GPU is `notebooks/IJIES_round2_experiments.ipynb` in Google Colab, which takes about 1.5 hours. Before the new runs, the notebook reran the seven detectors with the Names prompts, and all seven reproduced the published predictions exactly.

## Licence

The code is released under AGPL-3.0 (see `LICENSE`), the licence of the Ultralytics library it builds on.
