"""COCO-pretrained closed-vocabulary baseline: score only the classes COCO already contains
(truck, person, car) without any mining training."""
import argparse, json, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ovmine.data import NAMES, load
from ovmine.mapeval import evaluate
from ultralytics import YOLO

COCO2DS = {0: 5, 2: 6, 7: 0}          # COCO person->person, car->car, truck->truck
ap = argparse.ArgumentParser()
ap.add_argument("--data", type=Path, required=True)
ap.add_argument("--model", default="yolo11s.pt")
ap.add_argument("--split", default="test")
ap.add_argument("--device", default="cpu")
ap.add_argument("--imgsz", type=int, default=640)
ap.add_argument("--out", type=Path, default=ROOT / "results")
a = ap.parse_args()

imgs, gt = load(a.data, a.split)
model = YOLO(a.model)
pred, t0 = [], time.perf_counter()
for p in imgs:
    r = model.predict(str(p), conf=0.001, imgsz=a.imgsz, device=a.device, verbose=False,
                      classes=list(COCO2DS), max_det=100)[0]
    for b in r.boxes:
        pred.append({"image": p.name, "cls": COCO2DS[int(b.cls)],
                     "box": [float(v) for v in b.xyxy[0]], "score": float(b.conf)})
dt = (time.perf_counter() - t0) / max(1, len(imgs))
res = evaluate(gt, pred, list(COCO2DS.values()))
a.out.mkdir(parents=True, exist_ok=True)
tag = f"coco_{Path(a.model).stem}_{a.split}"
json.dump({"model": a.model, "classes_scored": [NAMES[c] for c in COCO2DS.values()],
           "AP50": res["AP50"], "AP50_95": res["AP50_95"], "sec_per_image": dt,
           "per_class": {NAMES[c]: res["per_class"][c] for c in res["per_class"]},
           "predictions": pred}, open(a.out / f"{tag}.json", "w"), indent=1)
print(f"{tag}: AP50 {100*res['AP50']:.1f} AP50-95 {100*res['AP50_95']:.1f} over "
      f"{[NAMES[c] for c in COCO2DS.values()]} ({dt:.2f}s/img)")
for c, v in res["per_class"].items():
    print(f"   {NAMES[c]:<8} AP50 {100*v['AP50']:.1f} AP50-95 {100*v['AP50_95']:.1f}")
