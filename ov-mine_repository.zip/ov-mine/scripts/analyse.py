"""Post-hoc analysis from saved prediction files: object-size bands, operating-point PR,
prompt-to-class confusion, and the figures used in the manuscript."""
import argparse, json, sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ovmine.data import NAMES, load
from ovmine.mapeval import evaluate, iou_matrix

ap = argparse.ArgumentParser()
ap.add_argument("--data", type=Path, required=True)
ap.add_argument("--results", type=Path, default=ROOT / "results")
ap.add_argument("--figs", type=Path, default=ROOT / "figs")
ap.add_argument("--conf", type=float, default=0.25, help="deployment operating point")
a = ap.parse_args()
a.figs.mkdir(parents=True, exist_ok=True)
_, gt = load(a.data, "test")
C = list(range(len(NAMES)))
BANDS = {"small (<32^2)": (0, 32**2), "medium (32^2-96^2)": (32**2, 96**2), "large (>96^2)": (96**2, 1e12)}

runs = {p.stem: json.load(open(p)) for p in sorted(a.results.glob("*_test.json"))}
print(f"{'run':38s} {'AP50':>6} {'AP50-95':>8} " + " ".join(f"{b:>18}" for b in BANDS))
rows = {}
for name, d in runs.items():
    pred = d["predictions"]
    line = {"AP50": 100 * d["AP50"], "AP50_95": 100 * d["AP50_95"]}
    for b, area in BANDS.items():
        line[b] = 100 * evaluate(gt, pred, C, area=area)["AP50"]
    # precision / recall / F1 at the operating point
    kept = [r for r in pred if r["score"] >= a.conf]
    tp = 0
    used = {}
    for r in sorted(kept, key=lambda r: -r["score"]):
        g = [i for i, x in enumerate(gt) if x["image"] == r["image"] and x["cls"] == r["cls"]]
        if not g:
            continue
        ious = iou_matrix(np.array([r["box"]], np.float32), np.array([gt[i]["box"] for i in g], np.float32))[0]
        j = int(np.argmax(ious))
        if ious[j] >= 0.5 and not used.get(g[j]):
            used[g[j]] = True
            tp += 1
    line["P"] = 100 * tp / max(1, len(kept))
    line["R"] = 100 * tp / len(gt)
    line["n_pred"] = len(kept)
    rows[name] = line
    print(f"{name:38s} {line['AP50']:6.1f} {line['AP50_95']:8.1f} " +
          " ".join(f"{line[b]:18.1f}" for b in BANDS) +
          f"   P@{a.conf} {line['P']:5.1f} R {line['R']:5.1f} kept {len(kept)}")
json.dump(rows, open(a.results / "analysis.json", "w"), indent=1)

# ---- figure 1: per-class AP50 for the three prompt sets of the small model
sel = [k for k in runs if k.startswith("yoloe-11s")]
if sel:
    fig, ax = plt.subplots(figsize=(6.4, 2.6))
    w = 0.26
    x = np.arange(len(NAMES))
    for i, k in enumerate(sorted(sel)):
        v = [100 * runs[k]["per_class"][n]["AP50"] for n in NAMES]
        ax.bar(x + (i - 1) * w, v, w, label=k.split("_")[1])
    ax.set_xticks(x); ax.set_xticklabels(NAMES, rotation=20, fontsize=8)
    ax.set_ylabel("AP50 (%)"); ax.legend(frameon=False, fontsize=8, title="prompt set", title_fontsize=8)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout(); fig.savefig(a.figs / "per_class_prompts.pdf", dpi=300)

# ---- figure 2: where the predicted class lands (confusion of matched detections)
best = "yoloe-11s-seg_names_test"
if best in runs:
    M = np.zeros((len(NAMES), len(NAMES) + 1))
    for r in [p for p in runs[best]["predictions"] if p["score"] >= a.conf]:
        g = [x for x in gt if x["image"] == r["image"]]
        if g:
            ious = iou_matrix(np.array([r["box"]], np.float32), np.array([x["box"] for x in g], np.float32))[0]
            j = int(np.argmax(ious))
            if ious[j] >= 0.5:
                M[r["cls"], g[j]["cls"]] += 1
                continue
        M[r["cls"], -1] += 1          # matched nothing: background
    Mn = M / np.maximum(M.sum(1, keepdims=True), 1)
    fig, ax = plt.subplots(figsize=(5.2, 3.4))
    im = ax.imshow(Mn, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(len(NAMES) + 1)); ax.set_xticklabels(NAMES + ["background"], rotation=35, fontsize=7, ha="right")
    ax.set_yticks(range(len(NAMES))); ax.set_yticklabels(NAMES, fontsize=7)
    ax.set_xlabel("ground truth at that location", fontsize=8); ax.set_ylabel("prompt that fired", fontsize=8)
    for i in range(len(NAMES)):
        for j in range(len(NAMES) + 1):
            if Mn[i, j] > 0.01:
                ax.text(j, i, f"{Mn[i,j]:.2f}", ha="center", va="center", fontsize=6,
                        color="white" if Mn[i, j] > 0.5 else "black")
    fig.colorbar(im, ax=ax, shrink=0.8)
    fig.tight_layout(); fig.savefig(a.figs / "prompt_confusion.pdf", dpi=300)
print("figures written to", a.figs)
