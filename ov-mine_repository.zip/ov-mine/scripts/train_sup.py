"""Supervised reference and label-efficiency runs with a separate validation split.
Training: subsets of the 111 training images. Checkpoint selection: 20 validation images (Ultralytics fitness).
Test: the 40 released test images, scored once per final model with ovmine.mapeval.
  python train_sup.py full            -> the supervised reference on all 111 images
  python train_sup.py le SIZE DRAW    -> label-efficiency run, SIZE in {11,28,56,111}, DRAW in 0..4 (seed = DRAW)"""
import json, random, shutil, sys, time
from collections import Counter
from pathlib import Path
import yaml
HERE = Path(__file__).resolve().parents[1]   # repository root
sys.path.insert(0, str(HERE))
from ovmine.data import NAMES, load
from ovmine.mapeval import evaluate
from ultralytics import YOLO

DATA, WORK = HERE / "data", HERE / "work"
S = json.load(open(HERE / "splits" / "split.json"))
import os
EPOCHS = int(os.environ.get("EPOCHS", 60)); IMGSZ = 640; BATCH = int(os.environ.get("BATCH", 8)); DEVICE = os.environ.get("DEVICE", "0")

def cls_of(n):
    return [int(float(l.split()[0])) for l in (DATA / n).with_suffix(".txt").read_text().splitlines() if l.strip()]

def stratified_subset(pool, k, seed):
    """One image per class first (rarest class first), then random fill."""
    rng = random.Random(seed); pool = sorted(pool); sel = []
    tot = Counter(c for n in pool for c in cls_of(n))
    for c in sorted(tot, key=lambda c: tot[c]):
        if len(sel) >= k: break
        if any(c in cls_of(n) for n in sel): continue
        cand = [n for n in pool if c in cls_of(n) and n not in sel]
        if cand: sel.append(rng.choice(cand))
    rest = [n for n in pool if n not in sel]; rng.shuffle(rest)
    return sorted(sel + rest[:k - len(sel)])

def run(tag, train_names, seed):
    root = WORK / tag
    shutil.rmtree(root, ignore_errors=True)
    for sp, files in (("train", train_names), ("val", S["val"])):
        (root / "images" / sp).mkdir(parents=True); (root / "labels" / sp).mkdir(parents=True)
        for n in files:
            shutil.copy2(DATA / n, root / "images" / sp / n)
            shutil.copy2((DATA / n).with_suffix(".txt"), root / "labels" / sp / Path(n).with_suffix(".txt").name)
    yaml.safe_dump({"path": str(root), "train": "images/train", "val": "images/val", "names": dict(enumerate(NAMES))},
                   open(root / "data.yaml", "w"))
    t0 = time.time()
    m = YOLO("yolo11s.pt")
    m.train(data=str(root / "data.yaml"), epochs=EPOCHS, imgsz=IMGSZ, batch=BATCH, device=DEVICE, workers=2,
            seed=seed, deterministic=True, patience=0, plots=False, verbose=False,
            project=str(WORK / "runs"), name=tag, exist_ok=True)
    best = WORK / "runs" / tag / "weights" / "best.pt"
    m = YOLO(str(best))                      # checkpoint chosen on the validation split only
    test_imgs, gt = load(DATA, "test")
    pred = []
    for p in test_imgs:                      # single scoring of the test split
        r = m.predict(str(p), conf=0.001, imgsz=IMGSZ, device=DEVICE, verbose=False, max_det=100)[0]
        for b in r.boxes:
            pred.append({"image": p.name, "cls": int(b.cls), "box": [float(v) for v in b.xyxy[0]], "score": float(b.conf)})
    res = evaluate(gt, pred, list(range(len(NAMES))))
    out = {"tag": tag, "seed": seed, "images": len(train_names), "train_images": train_names, "val_images": S["val"],
           "AP50": res["AP50"], "AP50_95": res["AP50_95"],
           "per_class": {NAMES[c]: res["per_class"][c] for c in res["per_class"]},
           "train_minutes": (time.time() - t0) / 60, "predictions": pred}
    (HERE / "results" / "supervised" / "logs").mkdir(parents=True, exist_ok=True)
    json.dump(out, open(HERE / "results" / "supervised" / f"{tag}.json", "w"), indent=1)
    shutil.copy2(WORK / "runs" / tag / "results.csv", HERE / "results" / "supervised" / "logs" / f"{tag}_results.csv")
    print(f"{tag}: AP50 {100*res['AP50']:.1f} AP50-95 {100*res['AP50_95']:.1f} ({out['train_minutes']:.0f} min)", flush=True)

if sys.argv[1] == "full":
    run("sup_full_s0", S["train"], 0)
else:
    k, d = int(sys.argv[2]), int(sys.argv[3])
    sel = S["train"] if k >= len(S["train"]) else stratified_subset(S["train"], k, d)
    run(f"le_n{k}_d{d}", sel, d)
