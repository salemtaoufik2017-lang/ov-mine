"""Zero-shot detection with the Hugging Face models (Grounding DINO, OWLv2, OWL-ViT).

  python scripts/run_hf_zeroshot.py --data DATA --model IDEA-Research/grounding-dino-tiny --prompts names
Writes the same JSON format as run_zeroshot.py so every model is scored by one evaluator.
"""
import argparse, json, sys, time
from pathlib import Path

import torch
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ovmine.data import NAMES, load          # noqa: E402
from ovmine.mapeval import evaluate          # noqa: E402
from ovmine.prompts import PROMPTS           # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--data", type=Path, required=True)
ap.add_argument("--model", default="IDEA-Research/grounding-dino-tiny")
ap.add_argument("--prompts", default="names", choices=list(PROMPTS))
ap.add_argument("--split", default="test")
ap.add_argument("--conf", type=float, default=0.05, help="Grounding DINO and OWLv2 need a floor > 0")
ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
ap.add_argument("--out", type=Path, default=ROOT / "results")
a = ap.parse_args()

from transformers import AutoModelForZeroShotObjectDetection, AutoProcessor  # noqa: E402

imgs, gt = load(a.data, a.split)
mapping = PROMPTS[a.prompts]
texts = list(mapping)
proc = AutoProcessor.from_pretrained(a.model)
model = AutoModelForZeroShotObjectDetection.from_pretrained(a.model).to(a.device).eval()
is_gdino = "grounding-dino" in a.model.lower()
# Grounding DINO takes one lower-case string with prompts separated by ". "
text_in = ". ".join(t.lower() for t in texts) + "." if is_gdino else [texts]

pred, t0 = [], time.perf_counter()
for p in imgs:
    im = Image.open(p).convert("RGB")
    inputs = proc(images=im, text=text_in, return_tensors="pt").to(a.device)
    with torch.no_grad():
        out = model(**inputs)
    if is_gdino:
        r = proc.post_process_grounded_object_detection(
            out, inputs.input_ids, threshold=a.conf, text_threshold=0.2,
            target_sizes=[im.size[::-1]])[0]
        labels = [str(x) for x in r["text_labels"]] if "text_labels" in r else [str(x) for x in r["labels"]]
    else:
        r = proc.post_process_grounded_object_detection(out, threshold=a.conf, target_sizes=[im.size[::-1]])[0]
        labels = [texts[int(i)] for i in r["labels"]]
    for box, score, lab in zip(r["boxes"], r["scores"], labels):
        # a phrase-grounding model can return a substring: match it back to a prompt
        key = next((t for t in texts if t.lower() in lab.lower() or lab.lower() in t.lower()), None)
        if key is None:
            continue
        pred.append({"image": p.name, "cls": mapping[key],
                     "box": [float(v) for v in box], "score": float(score)})
dt = (time.perf_counter() - t0) / max(1, len(imgs))
res = evaluate(gt, pred, list(range(len(NAMES))))
a.out.mkdir(parents=True, exist_ok=True)
tag = f"{a.model.split('/')[-1]}_{a.prompts}_{a.split}"
json.dump({"model": a.model, "prompts": a.prompts, "split": a.split, "images": len(imgs),
           "gt_boxes": len(gt), "pred_boxes": len(pred), "sec_per_image": dt,
           "AP50": res["AP50"], "AP50_95": res["AP50_95"],
           "per_class": {NAMES[c]: res["per_class"][c] for c in res["per_class"]},
           "predictions": pred}, open(a.out / f"{tag}.json", "w"), indent=1)
print(f"{tag}: AP50 {100*res['AP50']:.1f} AP50-95 {100*res['AP50_95']:.1f} "
      f"({len(pred)} detections, {dt:.2f}s/img on {a.device})")
