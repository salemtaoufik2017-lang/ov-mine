"""Score a fine-tuned checkpoint with the same evaluator as the zero-shot runs."""
import argparse, json, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ovmine.data import NAMES, load
from ovmine.mapeval import evaluate
from ultralytics import YOLO

ap = argparse.ArgumentParser()
ap.add_argument("--data", type=Path, required=True)
ap.add_argument("--weights", required=True)
ap.add_argument("--split", default="test")
ap.add_argument("--device", default="cpu")
ap.add_argument("--imgsz", type=int, default=640)
ap.add_argument("--tag", default="finetuned_yolo11s")
ap.add_argument("--out", type=Path, default=ROOT / "results")
a = ap.parse_args()
imgs, gt = load(a.data, a.split)
m = YOLO(a.weights)
pred, t0 = [], time.perf_counter()
for p in imgs:
    r = m.predict(str(p), conf=0.001, imgsz=a.imgsz, device=a.device, verbose=False, max_det=100)[0]
    for b in r.boxes:
        pred.append({"image": p.name, "cls": int(b.cls), "box": [float(v) for v in b.xyxy[0]],
                     "score": float(b.conf)})
dt = (time.perf_counter() - t0) / max(1, len(imgs))
res = evaluate(gt, pred, list(range(len(NAMES))))
a.out.mkdir(parents=True, exist_ok=True)
json.dump({"model": a.weights, "prompts": "---", "split": a.split, "images": len(imgs),
           "gt_boxes": len(gt), "pred_boxes": len(pred), "sec_per_image": dt,
           "AP50": res["AP50"], "AP50_95": res["AP50_95"],
           "per_class": {NAMES[c]: res["per_class"][c] for c in res["per_class"]},
           "predictions": pred}, open(a.out / f"{a.tag}_{a.split}.json", "w"), indent=1)
print(f"{a.tag}: AP50 {100*res['AP50']:.1f} AP50-95 {100*res['AP50_95']:.1f} ({dt:.2f}s/img)")
for c, v in res["per_class"].items():
    print(f"   {NAMES[c]:<14} AP50 {100*v['AP50']:.1f}")
