"""Zero-shot / open-vocabulary detection on the open-pit machinery set.

  python scripts/run_zeroshot.py --data /path/to/dataset --model yolov8s-worldv2.pt --prompts names
Writes predictions to results/<model>_<prompts>.json and prints mAP.
"""
import argparse, json, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ovmine.data import NAMES, load          # noqa: E402
from ovmine.mapeval import evaluate          # noqa: E402
from ovmine.prompts import PROMPTS           # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--data", type=Path, required=True)
ap.add_argument("--model", default="yolov8s-worldv2.pt")
ap.add_argument("--prompts", default="names", choices=list(PROMPTS))
ap.add_argument("--split", default="test", choices=["all", "test", "train"])
ap.add_argument("--conf", type=float, default=0.001)
ap.add_argument("--imgsz", type=int, default=640)
ap.add_argument("--device", default="cpu")
ap.add_argument("--out", type=Path, default=ROOT / "results")
a = ap.parse_args()

imgs, gt = load(a.data, a.split)
mapping = PROMPTS[a.prompts]
texts = list(mapping)

from ultralytics import YOLO, YOLOE  # noqa: E402
is_yoloe = "yoloe" in a.model
model = (YOLOE if is_yoloe else YOLO)(a.model)
if is_yoloe:
    model.set_classes(texts, model.get_text_pe(texts))
else:
    model.set_classes(texts)

pred, t0 = [], time.perf_counter()
for p in imgs:
    r = model.predict(str(p), conf=a.conf, imgsz=a.imgsz, device=a.device, verbose=False, max_det=100)[0]
    for b in r.boxes:
        pred.append({"image": p.name, "cls": mapping[texts[int(b.cls)]],
                     "box": [float(v) for v in b.xyxy[0]], "score": float(b.conf)})
dt = (time.perf_counter() - t0) / max(1, len(imgs))

res = evaluate(gt, pred, list(range(len(NAMES))))
a.out.mkdir(parents=True, exist_ok=True)
tag = f"{Path(a.model).stem}_{a.prompts}_{a.split}"
json.dump({"model": a.model, "prompts": a.prompts, "split": a.split, "images": len(imgs),
           "gt_boxes": len(gt), "pred_boxes": len(pred), "sec_per_image": dt,
           "AP50": res["AP50"], "AP50_95": res["AP50_95"],
           "per_class": {NAMES[c]: res["per_class"][c] for c in res["per_class"]},
           "predictions": pred}, open(a.out / f"{tag}.json", "w"), indent=1)
print(f"{tag}: images {len(imgs)} gt {len(gt)} pred {len(pred)} "
      f"AP50 {100*res['AP50']:.1f} AP50-95 {100*res['AP50_95']:.1f} ({dt:.2f}s/img)")
for c, v in res["per_class"].items():
    print(f"   {NAMES[c]:<14} AP50 {100*v['AP50']:.1f}" if v["AP50"] == v["AP50"] else f"   {NAMES[c]:<14} no GT")
