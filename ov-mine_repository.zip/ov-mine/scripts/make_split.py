"""Divide the 131 non-test images into 111 training and 20 validation images.
Near-duplicate frames (pHash distance <= 10) form groups that stay on one side.
Class-stratified: rarest class first, one group per class if it can be spared, then random fill. Seed 0."""
import json, random, sys
from pathlib import Path
from collections import Counter
import imagehash
from PIL import Image
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ovmine.data import NAMES, load

DATA = ROOT / "data"
train_imgs, _ = load(DATA, "train")
test_imgs, _ = load(DATA, "test")
H = {p.name: imagehash.phash(Image.open(p)) for p in train_imgs}
names = [p.name for p in train_imgs]
parent = {n: n for n in names}
def find(x):
    while parent[x] != x:
        parent[x] = parent[parent[x]]; x = parent[x]
    return x
for i, a in enumerate(names):
    for b in names[i + 1:]:
        if H[a] - H[b] <= 10: parent[find(a)] = find(b)
groups = {}
for n in names: groups.setdefault(find(n), []).append(n)
groups = sorted(groups.values(), key=lambda g: sorted(g)[0])
cls_of = {p.name: [int(float(l.split()[0])) for l in p.with_suffix(".txt").read_text().splitlines() if l.strip()] for p in train_imgs}
gcls = [Counter(c for n in g for c in cls_of[n]) for g in groups]
total = Counter(c for n in names for c in cls_of[n])
rng = random.Random(0)
val, used = [], set()
for c in sorted(range(len(NAMES)), key=lambda c: total[c]):
    cand = [i for i, gc in enumerate(gcls) if gc[c] and i not in used and gc[c] <= total[c] / 3]
    if cand and len(val) < 20:
        i = rng.choice(cand); used.add(i); val += groups[i]
rest = [i for i in range(len(groups)) if i not in used]
rng.shuffle(rest)
for i in rest:
    if len(val) >= 20: break
    if len(val) + len(groups[i]) <= 20: used.add(i); val += groups[i]
val = sorted(val); tr = sorted(n for n in names if n not in val)
vc = Counter(c for n in val for c in cls_of[n]); tc = Counter(c for n in tr for c in cls_of[n])
out = {"seed": 0, "phash_threshold": 10, "n_groups_nontest": len(groups),
       "train": tr, "val": val, "test": sorted(p.name for p in test_imgs),
       "boxes_train": {NAMES[c]: tc[c] for c in range(7)}, "boxes_val": {NAMES[c]: vc[c] for c in range(7)}}
json.dump(out, open(ROOT / "splits" / "split.json", "w"), indent=1)
print(len(tr), len(val), len(groups), out["boxes_train"], out["boxes_val"])
