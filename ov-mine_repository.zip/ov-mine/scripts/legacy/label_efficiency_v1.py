"""How many labelled images does the supervised alternative need to beat zero-shot?

Trains YOLO11s on nested random subsets of the training split and scores each one with the
same evaluator used for the zero-shot runs.

  python scripts/label_efficiency.py --data DATA --fractions 0.1 0.25 0.5 1.0 --device 0
"""
import argparse, json, random, shutil, sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ovmine.data import NAMES, load          # noqa: E402
from ovmine.mapeval import evaluate          # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--data", type=Path, required=True, help="folder with the jpg/txt pairs")
ap.add_argument("--work", type=Path, default=Path("/content/le"))
ap.add_argument("--fractions", type=float, nargs="+", default=[0.1, 0.25, 0.5, 1.0])
ap.add_argument("--model", default="yolo11s.pt")
ap.add_argument("--epochs", type=int, default=60)
ap.add_argument("--imgsz", type=int, default=640)
ap.add_argument("--batch", type=int, default=8)
ap.add_argument("--device", default="0")
ap.add_argument("--seeds", type=int, nargs="+", default=[0])
ap.add_argument("--out", type=Path, default=ROOT / "results")
a = ap.parse_args()

from ultralytics import YOLO  # noqa: E402

train_imgs, _ = load(a.data, "train")
test_imgs, gt = load(a.data, "test")
rows = []
for seed in a.seeds:
    for f in a.fractions:
        sel = random.Random(seed).sample(train_imgs, max(1, round(len(train_imgs) * f)))
        root = a.work / f"f{f:g}_s{seed}"
        shutil.rmtree(root, ignore_errors=True)
        for sp, files in (("train", sel), ("val", test_imgs)):
            (root / "images" / sp).mkdir(parents=True, exist_ok=True)
            (root / "labels" / sp).mkdir(parents=True, exist_ok=True)
            for im in files:
                shutil.copy2(im, root / "images" / sp / im.name)
                lb = im.with_suffix(".txt")
                if lb.exists():
                    shutil.copy2(lb, root / "labels" / sp / lb.name)
        yaml.safe_dump({"path": str(root), "train": "images/train", "val": "images/val",
                        "names": dict(enumerate(NAMES))}, open(root / "data.yaml", "w"))
        m = YOLO(a.model)
        m.train(data=str(root / "data.yaml"), epochs=a.epochs, imgsz=a.imgsz, batch=a.batch,
                device=a.device, seed=seed, deterministic=True, plots=False, verbose=False,
                project=str(a.work / "runs"), name=f"f{f:g}_s{seed}", exist_ok=True)
        pred = []
        for p in test_imgs:
            r = m.predict(str(p), conf=0.001, imgsz=a.imgsz, device=a.device, verbose=False, max_det=100)[0]
            for b in r.boxes:
                pred.append({"image": p.name, "cls": int(b.cls), "box": [float(v) for v in b.xyxy[0]],
                             "score": float(b.conf)})
        res = evaluate(gt, pred, list(range(len(NAMES))))
        rows.append({"fraction": f, "seed": seed, "images": len(sel),
                     "AP50": res["AP50"], "AP50_95": res["AP50_95"]})
        print(f"fraction {f:<5g} seed {seed} images {len(sel):3d}  "
              f"AP50 {100*res['AP50']:.1f}  AP50-95 {100*res['AP50_95']:.1f}", flush=True)
        json.dump(rows, open(a.out / "label_efficiency.json", "w"), indent=1)

# figure: labelled images against accuracy, with the best zero-shot line
import matplotlib; matplotlib.use("Agg")           # noqa: E402
import matplotlib.pyplot as plt                     # noqa: E402
import numpy as np                                  # noqa: E402
zs = 0.0
for p in (a.out).glob("yoloe*_names_test.json"):
    zs = max(zs, json.load(open(p))["AP50"])
xs = sorted({r["images"] for r in rows})
ys = [100 * np.mean([r["AP50"] for r in rows if r["images"] == x]) for x in xs]
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
fig, ax = plt.subplots(figsize=(3.6, 2.4))
ax.plot(xs, ys, marker="o", color="#2a6f97", label="fine-tuned YOLO11s")
ax.axhline(100 * zs, ls="--", color="#e07a1f", label="best zero-shot")
ax.set_xlabel("labelled training images"); ax.set_ylabel("AP50 (%)")
ax.legend(frameon=False, fontsize=8)
fig.tight_layout(); fig.savefig(ROOT / "figs" / "label_efficiency.pdf", dpi=300, bbox_inches="tight")
print("wrote figs/label_efficiency.pdf")
